
$('#1').addClass('show');
var count=0;
var i = 0;
var imgs=new Array('https://975c0837-a-62cb3a1a-s-sites.googlegroups.com/site/youmorestop/home/proba/Eiffel-Tower-5.jpg?attachauth=ANoY7cq7nYnEWQ1WHbFhClSwpDRStfYjDlpwqj4z_H4JBG5xtvRJv2TZi-X7zOgJZ8YRToJ3XbypPjs60FCy3ACzKlkt7ah6_tqy9PihgWSyQGAXQ9HI_uzBockr-PgDNHc2-g7nBejFZDiZy--6dcYx9wGq_G6Lqjel_y7hl0zciWFjrnD7YqV74S2gZ7QViuPcOtPx3UtVueqtT4C7ZyGBu17W8lAw3iesqlgNr7dmNUhBLpY51oY%3D&attredirects=0','https://975c0837-a-62cb3a1a-s-sites.googlegroups.com/site/youmorestop/home/proba/Eiffel-Tower-4.jpg?attachauth=ANoY7cpHHrQ6JftqViw9V0rPpYKk1cXqVrZYxmMVflkg9aE8PrJHB8c1YQgFPZRvDwaWZzOAsWasLliRVhrCqUYB3TTBe4D8e19JGCM1iayW4JRDcn2PA6HtCOQMHsc-mAorSoFcB9JGd_YzVxQUduyxT2cf_Ic-YQfZP39w6OmdWvKwWyVMa7GyxYABBGVz_SgN8AnHihwT6Bf6md1zUz9aA0KFoOqPrV0DiDB1U8btmM1SeR97HzA%3D&attredirects=0', 'https://975c0837-a-62cb3a1a-s-sites.googlegroups.com/site/youmorestop/home/proba/Eiffel-Tower-3.jpg?attachauth=ANoY7cpte_rBNJUI_P0SogMQIHpF4-dCq6hu6yGeIWRbauLqLpG8HHRoSHyTjl2VvcFK0ccmK2TzJPKut3sAk--TpuShMo4nMt0rZavmx0TB5QDt5yxEvWsrNzOGBFo0e0WuDarcX_51v-049QNH18c1OnG0TYNP-42Py8uQoPk6TT4Sp3tD1IVwJ922RpHQg8VkPvawK_YzEmWveCCUDaei-ey4-gzpx9hPDo9JeRyVaiQc6vGKIuw%3D&attredirects=0',
	'https://975c0837-a-62cb3a1a-s-sites.googlegroups.com/site/youmorestop/home/proba/Eiffel-Tower-2.jpg?attachauth=ANoY7craMhO12wTxne76AIflhdbx7bT7PUPlpCHpo2Bo-m6IlwspQ6mR1weYOPgXIgzQlv_FxNWSNJOf9MQzbLUy5GHQ180VbzPaPBiYLKf7Ltg3HYdSb4aC9ekDpyctLGpNLScg_uZrKqhiFpEATBDc7CV0vjKeqUUMVYw9vv3hP6xk18fKGnDuj1YmXUnJrAJjUb9wX-lR2TKQ_kUQ8RDatV-alJjJlGp5X4v_a1OpA9iphDajTvY%3D&attredirects=0','https://975c0837-a-62cb3a1a-s-sites.googlegroups.com/site/youmorestop/home/proba/Eiffel-Tower-1.jpg?attachauth=ANoY7crvnieZHgiGcqvnOfowkvqezASiiM2csn22R0DUpqVCsFdWRNbPEWgp4koitllkZsRPcMz6ku6d19M16GAuKM-v4AK9wHr0EefKgglIKLdAlIpf-k8B7eNcnOTOkJVfMVvlisOeMZqCA6brL8cmCyCiHtOqBSw6sXKO6FKHQ84FZskwbRm7-hDEKZySkqqr9xNtkm9SIaNXZDC2s3kG_KOmQsJZ__HoGcJQ3oeKYiTuT3IAklU%3D&attredirects=0','https://975c0837-a-62cb3a1a-s-sites.googlegroups.com/site/youmorestop/home/proba/Eiffel-Tower.jpg?attachauth=ANoY7cpVB5It_Gan6Hm500c3DiQU3m-NsMhw3xdadWk8ENW5RVYp4JB2NUzNnq2TRSaWd-oK077VtOK25dgnjvS_4k9m1TVOBLiTXripuWPtDfFS9uyqY16MeqN4yRko7dpRBQFl28IP0E7kbBXGpDCrQPeY7N3DAsm2Pia00WpN-3ngBfNbfbNm306eE3HHhgSXImieZK6EdtuWWGXxgmRw9Eh8l3redTmEVDju6RFLu-hhwNq4K4Y%3D&attredirects=0','https://975c0837-a-62cb3a1a-s-sites.googlegroups.com/site/youmorestop/home/proba/Eiffel-Tower-end.jpg?attachauth=ANoY7cqLwfrTj1g-82yscNkkqajQLXi2b1LS3AqSvF4UIqyuL_6BdpANk-gbkF8SSg78LoyyiGjnqDZ3qNtOb4rQTyCGFFZ3ScJE2nC5nc9jDBPx-YQuLdZj-ECdK6At7ezVx0d_fcojmlE7I8PBHueSonIAIURTRLwmhxFLQgnqnqSsXqb1CA_ty43o2DCU1qF6QV3a9wxW9tP8opSM9hrrKl16C3dz-Asi1GC753nGv86vHTR1QIE%3D&attredirects=0');
var checks;
var check;

var ans1 = "Вы не любите башни и правильно делаете! От них исходит угроза текстанических сдвигов эстетического восприятия всего человечества. Держитесь от них подальше.";
var ans2 = " Когда для Вас открыт весь Мир, то Вы не будете вязнуть в деталях Вы идете к своим целям легко и беспечно.Пара мелких штрихов к глобальному портрету великих творений Вас не интересуют. Вы смотрите на все творения в целом и не склонны замечать мелких деталей.";
var ans3 = "Вы эрудит, и Вас мало интересуют технические нюансы и мелкие подробности. Вы смотрите на Мир широко и глобально. Вам откроются огромные перспективы, если вы чуть-чуть уделите внимание деталям.";
var ans4 = "Потрясающий результат! Вы обладаете тонким техническим умом и здравым расчетом. Вашей памяти могут позавидовать лучшие умы Человечества. Если Вы ставите цель и прикладываете усилия, то у Вас нет соперников.Вы способны достичь невероятных успехов и покорять любые вершины.";
var ans5 ="Вы Александр Гюстав Эйфель  или его дочь? Вы ответили на все вопросы абсолютно правильно. Вы входите в число той редкой группы людей, которая может видеть глобально не упуская детали. Вы гений современности!";
function changeImg(){
	  checks = document.getElementsByName('radio');
	   for(var k=0; k<checks.length; k++)
    if (checks[k].checked) {
       check = $('input[name=radio]:checked').val();
      checks[k].checked = false;
    } 
 var image=document.getElementById("image");
	if(check =='3' || check =='6' || check =='12' || check =='13' || check =='20' || check =='23' || check =='26' ){
     i++;
      
     count = count+1;
     
     image.src=imgs[i];
     if(image.src==undefined) image.src='img/Eiffel-Tower-end.jpg';
      check = 0;  
       
	} 	
	
}


function answer(count){
	if(count <=2 ){
	document.getElementById("answer").innerHTML = "Правильных ответов " + count + " из 7" +"<br />" + ans1; 
	} else if (count == 3){
	document.getElementById("answer").innerHTML = "Правильных ответов " + count + " из 7" + "<br />" +ans2;
	}else if (count ==4){
	document.getElementById("answer").innerHTML = "Правильных ответов " + count + " из 7" + "<br />" +ans3;
	}else if (count == 5){
	document.getElementById("answer").innerHTML = "Правильных ответов " + count + " из 7" + "<br />" +ans4;
	}else if (count == 6){
	document.getElementById("answer").innerHTML = "Правильных ответов " + count + " из 7" + "<br />" +ans4; 
	}else if (count == 7){
	document.getElementById("answer").innerHTML = "Правильных ответов " + count + " из 7" + "<br />" +ans5; 
	}
}


function meChange(){
  
 changeImg();


	if($('#1').hasClass('show')){
		$('#1').addClass('show').removeClass('show');
		$('#1').addClass('hidden');
		$('#2').addClass('show');

	} else if($('#2').hasClass('show')){
		$('#2').addClass('show').removeClass('show');
		$('#2').addClass('hidden');
		$('#3').addClass('show');
	} else if($('#3').hasClass('show')){
		$('#3').addClass('show').removeClass('show');
		$('#3').addClass('hidden');
		$('#4').addClass('show');
	} else if($('#4').hasClass('show')){
		$('#4').addClass('show').removeClass('show');
		$('#4').addClass('hidden');
		$('#5').addClass('show');
	} else if($('#5').hasClass('show')){
		$('#5').addClass('show').removeClass('show');
		$('#5').addClass('hidden');
		$('#6').addClass('show');
	} else if($('#6').hasClass('show')){
		$('#6').addClass('show').removeClass('show');
		$('#6').addClass('hidden');
		$('#7').addClass('show');
	}else if($('#7').hasClass('show')){
		$('#7').addClass('show').removeClass('show');
		$('#7').addClass('hidden');
		$('#8').addClass('show');
		$('button').addClass('hidden');
		answer(count);
	}
 
}